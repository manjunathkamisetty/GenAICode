def main():
    print("Hello from blogagentic!")


if __name__ == "__main__":
    main()
