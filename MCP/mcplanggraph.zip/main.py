def main():
    print("Hello from mcpdemolangchain!")


if __name__ == "__main__":
    main()
